import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Person here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Person extends Actor
{
    /**
     * Act - do whatever the Person wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    private int speed=7; //incremento do movimento lateral
    private int verticalSpeed=0;//incremento do movimento vertical
    private int acceleration=2;
    private int jumpStrenght=18;
    //private GreenfootImage imagePerson;
    private GreenfootImage agentSpriteDireita[] = new GreenfootImage[9];
    private GreenfootImage agentSpriteEsquerda[] = new GreenfootImage[9];
    private int frame = 0;
    private int delay = 0;
    
    private String leftKey;
    private String rightKey;
    private String jumpKey;
    public Person(String leftKey, String rightKey, String jumpKey, String imageName){
        this.leftKey = leftKey;
        this.rightKey = rightKey;
        this.jumpKey = jumpKey;
        //setImage("person.png");
        //imagePerson= getImage();
        //int larguraAtual= imagePerson.getWidth();
        //int alturaAtual= imagePerson.getHeight();
        //imagePerson.scale(larguraAtual*2, alturaAtual*2);
        /**Um ciclo para fazer set dos sprites dos personagens */
        for (int i = 0; i <= 8; i++) {
            agentSpriteDireita[i] = new GreenfootImage("agente/frame_00" + i + ".png");
            
            //Scale para deixar o sprite maior
            int larguraAtual= agentSpriteDireita[i].getWidth();
            int alturaAtual= agentSpriteDireita[i].getHeight();
            agentSpriteDireita[i].scale(larguraAtual*2, alturaAtual*2);
            //Inverter a imagem da direita pra esquerda
            agentSpriteEsquerda[i] = new GreenfootImage(agentSpriteDireita[i]);
            agentSpriteEsquerda[i].mirrorHorizontally();
        }
        setImage(agentSpriteDireita[0]);
    }
    public void act() {
        checkKeys();
        checkFall();
    }
    /**se o jogador pressionar -> mexe para a direita, se presionar
     * <- mexe para a esquerda e inverte a imagem 
     */ 
    public void  checkKeys(){
        if (Greenfoot.isKeyDown(leftKey) &&  !touchingWall(-getImage().getWidth()/2 - speed)){
            animar(agentSpriteEsquerda);
            setLocation(getX()-speed, getY());
        }
         if (Greenfoot.isKeyDown(rightKey) && !touchingWall(getImage().getWidth()/2 + speed)){
            animar(agentSpriteDireita);
            setLocation(getX()+speed, getY());
        }
        if(Greenfoot.isKeyDown(jumpKey)&& onGround()){
            jump();
        }
    }
    public void fall(){
        setLocation(getX(), getY()+ verticalSpeed);
        verticalSpeed +=acceleration;
    }
    public boolean onGround(){
        Actor under= getOneObjectAtOffset(0, getImage().getHeight() /2+1, Ground.class );
        return under!=null;
    }
    public void checkFall(){
        if (onGround()&& verticalSpeed >= 0){
            while (getOneObjectAtOffset(0, getImage().getHeight()/2, Ground.class) != null){
                setLocation(getX(), getY()-1);
            }
            verticalSpeed=0;
        }
        else {
            fall();
        }
    }
    public void jump(){
        verticalSpeed=-jumpStrenght;
        fall();
    }
    public void animar (GreenfootImage[] sprites) {
        delay++;
        if (delay % 6 == 0) { 
            frame = (frame + 1) % sprites.length;
            setImage(sprites[frame]);
        }
    }
    
    public boolean touchingWall(int dx){
    return getOneObjectAtOffset(dx, 0, Wall.class) != null;
}

}
    
    

